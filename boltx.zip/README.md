__FUCK__
```xml
< why bot is not runing man >
```
```kotlin
"why"
```
<a href="https://top.gg/bot/904583213891072091">
  <img src="https://top.gg/api/widget/904583213891072091.svg">
</a>